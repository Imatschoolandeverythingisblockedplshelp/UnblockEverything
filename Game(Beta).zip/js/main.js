//import { initializeApp } from "https://www.gstatic.com/firebasejs/9.8.1/firebase-app.js";
//import { initializeApp } from "https://www.gstatic.com/firebasejs/9.8.1/firebase-database.js";
var webview = document.getElementById('currentView');
var bullet = document.getElementById('drag');
var insert_style = '.window-overlay::-webkit-scrollbar{height:33px;width:33px}.window-overlay::-webkit-scrollbar-thumb{min-height:50px;background:rgba(255,255,255,1);border-radius:17px;border:10px solid transparent;background-clip:padding-box}.window-overlay::-webkit-scrollbar-track-piece{background:rgba(0,0,0,.5);border:10px solid transparent;background-clip:padding-box}.window-overlay::-webkit-scrollbar-track-piece:vertical:start{border-radius:17px 17px 0 0}.window-overlay::-webkit-scrollbar-track-piece:vertical:end{border-radius:0 0 17px 17px}';
var NODE_TLS_REJECT_UNAUTHORIZED = '0'
var createTabBtn = document.getElementById("createTab");
var view = document.querySelector(".tab1View");
var view2 = document.querySelector(".tab2View");
var view3 = document.querySelector(".tab3View");
var view4 = document.querySelector(".tab4View");
var view5 = document.querySelector(".tab5View");
var tab1 = document.getElementById("tab1");
var tab11 = document.getElementById("tab11");
var tab2 = document.getElementById("tab2");
var tab22 = document.getElementById("tab22");
var tab3 = document.getElementById("tab3");
var tab33 = document.getElementById("tab33");
var tab4 = document.getElementById("tab4");
var tab44 = document.getElementById("tab44");
var tab5 = document.getElementById("tab5");
var tab55 = document.getElementById("tab55");
var deleteTabSelector = document.querySelector(".deleteTabSelection");
let currentTab = 1;
let tabSelected = 1;
var selection = document.querySelector("select");
var saveTabData = false;
var settingsBtn = document.getElementById("settingsOpen");
var settings = document.querySelector(".settingsDiv");
var opened = false;
/*var searchBar = document.getElementById("searchBar");
var searchBarOn = false;
var searchBtn = document.getElementById("searchBtn");*/
var webBar = document.getElementById("webBar");
/*var tabsBar = document.getElementById("tabBar");
var tabsOn = false;
var tabsBtn = document.getElementById("tabsBtn");*/
var saveTabDataBar = document.getElementById("saveTabDataBar");
var saveTabDataBtn = document.getElementById("saveBtn");
var tab1Shown = true;
var tab2Shown = false;
var tab3Shown = false;
var tab4Shown = false;
var tab5Shown = false;
/*var waterBar = document.getElementById("waterBar");
var waterOn = false;
var waterBtn = document.getElementById("waterBtn");
var watermark = document.querySelector(".watermark");*/
var bookmarksBar = document.querySelector(".bookmarksBar");
var bookmarkSelection = document.querySelector(".bookmarkSelection");
var adBlock2 = document.querySelector(".adBlock2");
var name = "";
var pass = "";
var xtab1 = document.querySelector(".xtab1");
var xtab2 = document.querySelector(".xtab2");
var xtab3 = document.querySelector(".xtab3");
var xtab4 = document.querySelector(".xtab4");
var xtab5 = document.querySelector(".xtab5");
var field = document.querySelector(".field");
var submit = document.querySelector(".submit");
var txt = document.querySelector(".txt");

// Your web app's Firebase configuration
/*const firebaseConfig = {
    apiKey: "AIzaSyBjBCBDCGBfxgv7ymeutf7y_QdmFllQJOk",
    authDomain: "ube-saving.firebaseapp.com",
    projectId: "ube-saving",
    storageBucket: "ube-saving.appspot.com",
    messagingSenderId: "494810928696",
    appId: "1:494810928696:web:12dd2b33d1540c4c8eb8cd"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// Initialize Variables
const fireRef = firebase.database().ref('Accounts');

// Set Up The Register Function
function register() {
    const account = "Username: " + name + " Password: " + pass;
    fireRef.once("value", function(snapshot) {
        var data = snapshot.val();
        for (let i in data) {
            if (account === data[i]) {
                console.log(data);
            }
        }
    })
}*/

submit.addEventListener("click", function() {
    if (field.value == "marioisangry") {
        txt.innerText = "Your Mom";
        document.querySelector(".topBar").classList.remove("your-mother");
        document.querySelector(".settingsDiv").classList.remove("your-mother");
        document.querySelector("#controls").classList.remove("your-mother");
        document.querySelector(".field").remove();
        document.querySelector(".submit").classList.add("your-mother");
        document.querySelector(".txt").classList.add("your-mother");
    } else {
        txt.innerText =  "Your Password Is Incorrect Please DO NOT Contact An Admin";
    }
});

adBlock2.addEventListener('click', function() {
    
});

/*waterBtn.addEventListener('click', function() {
    if (waterOn == false) {
        waterBar.innerText = "On";
        waterOn = true;
        waterBtn.innerText = "Turn Off";
        watermark.classList.add("hidden");
    } else {
        waterBar.innerText = "Off";
        waterOn = false;
        waterBtn.innerText = "Turn On";
        watermark.classList.remove("hidden");
    }
})*/

saveTabDataBtn.addEventListener('click', function() {
    if (saveTabData == false) {
        saveTabDataBar.innerText = "On";
        saveTabData = true;
        saveTabDataBtn.innerText = "Turn Off";
    } else {
        saveTabDataBar.innerText = "Off";
        saveTabData = false;
        saveTabDataBtn.innerText = "Turn On";
    }
})

/*tabsBtn.addEventListener('click', function() {
    if (tabsOn == true) {
        tabsBar.innerText = "On";
        tabsOn = false;
        tabsBtn.innerText = "Turn Off";
        if (tab1.classList.contains("hidden") && tab11.classList.contains("hidden") && tab1Shown == true) {
            tab1.classList.remove("hidden");
            tab11.classList.remove("hidden");
        }

        if (tab2.classList.contains("hidden") && tab22.classList.contains("hidden") && tab2Shown == true) {
            tab2.classList.remove("hidden");
            tab22.classList.remove("hidden");
        }

        if (tab3.classList.contains("hidden") && tab33.classList.contains("hidden") && tab3Shown == true) {
            tab3.classList.remove("hidden");
            tab33.classList.remove("hidden");
        }

        if (tab4.classList.contains("hidden") && tab44.classList.contains("hidden") && tab4Shown == true) {
            tab4.classList.remove("hidden");
            tab44.classList.remove("hidden");
        }

        if (tab5.classList.contains("hidden") && tab55.classList.contains("hidden") && tab5Shown == true) {
            tab5.classList.remove("hidden");
            tab55.classList.remove("hidden");
        }
    } else {
        tabsBar.innerText = "Off";
        tabsOn = true;
        tabsBtn.innerText = "Turn On";
        if (!tab1.classList.contains("hidden") && !tab11.classList.contains("hidden")) {
            tab1.classList.add("hidden");
            tab11.classList.add("hidden");
        }

        if (!tab2.classList.contains("hidden") && !tab22.classList.contains("hidden")) {
            tab2.classList.add("hidden");
            tab22.classList.add("hidden");
        }

        if (!tab3.classList.contains("hidden") && !tab33.classList.contains("hidden")) {
            tab3.classList.add("hidden");
            tab33.classList.add("hidden");
        }

        if (!tab4.classList.contains("hidden") && !tab44.classList.contains("hidden")) {
            tab4.classList.add("hidden");
            tab44.classList.add("hidden");
        }

        if (!tab5.classList.contains("hidden") && !tab55.classList.contains("hidden")) {
            tab5.classList.add("hidden");
            tab55.classList.add("hidden");
        }
    }
})

searchBtn.addEventListener('click', function() {
    if (searchBarOn == true) {
        searchBar.innerText = "On";
        searchBarOn = false;
        searchBtn.innerText = "Turn Off";
        webBar.style.display = "block";
        bookmarksBar.classList.remove("hidden");
    } else {
        searchBar.innerText = "Off";
        searchBarOn = true;
        searchBtn.innerText = "Turn On";
        webBar.style.display = "none";
        bookmarksBar.classList.add("hidden");
    }
});*/

settingsBtn.addEventListener('click', function() {
    if (opened == false) {
        settings.style.display = "block";
        opened = true;
    } else {
        settings.style.display = "none";
        opened = false;
    }
});

settings.style.display = "none";

view2.id = "NoView";
view2.style.display = "none";
view3.id = "NoView";
view3.style.display = "none";
view4.id = "NoView";
view4.style.display = "none";
view5.id = "NoView";
view5.style.display = "none";

window.addEventListener('focus', function(e) {
    webview.focus();
});

webview.addEventListener('permissionrequest', function(e) {
    if (e.permission === 'download')
        e.request.allow();
});

chrome.runtime.onMessage.addListener(function(request, sender) {
    if (sender.id == appID) {
        webview.src = request;
    }
});

createTabBtn.addEventListener('click', function() {
    if (currentTab < 5) {
        currentTab++;
        var variable = "tab"+currentTab
        var variable2 = "tab"+currentTab+currentTab
        document.getElementById(variable + "Option").removeAttribute("hidden");
        document.getElementById(variable).classList.remove("hidden");
        document.getElementById(variable2).classList.remove("hidden");
        
        if (currentTab == 1) {
            tabSelected = 1;
            tab1.checked = true;
            view.id = "currentView";
            view.style.display = "block";
            view2.id = "NoView";
            view2.style.display = "none";
            view3.id = "NoView";
            view3.style.display = "none";
            view4.id = "NoView";
            view4.style.display = "none";
            view5.id = "NoView";
            view5.style.display = "none";
            tab11.classList.add("active")
            tab22.classList.remove("active")
            tab33.classList.remove("active")
            tab44.classList.remove("active")
            tab55.classList.remove("active")
            tab11.style.backgroundColor = "#383838";
            tab22.style.backgroundColor = "#5d5d5d";
            tab33.style.backgroundColor = "#5d5d5d";
            tab44.style.backgroundColor = "#5d5d5d";
            tab55.style.backgroundColor = "#5d5d5d";
            tab11.style.color = "#ffffff";
            tab22.style.color = "#b2b2b2";
            tab33.style.color = "#b2b2b2";
            tab44.style.color = "#b2b2b2";
            tab55.style.color = "#b2b2b2";
        }

        if (currentTab == 2) {
            tabSelected = 2;
            tab2.checked = true;
            view.id = "NoView";
            view.style.display = "none";
            view2.id = "currentView";
            view2.style.display = "block";
            view3.id = "NoView";
            view3.style.display = "none";
            view4.id = "NoView";
            view4.style.display = "none";
            view5.id = "NoView";
            view5.style.display = "none";
            tab11.classList.remove("active")
            tab22.classList.add("active")
            tab33.classList.remove("active")
            tab44.classList.remove("active")
            tab55.classList.remove("active")
            tab11.style.backgroundColor = "#5d5d5d";
            tab22.style.backgroundColor = "#383838";
            tab33.style.backgroundColor = "#5d5d5d";
            tab44.style.backgroundColor = "#5d5d5d";
            tab55.style.backgroundColor = "#5d5d5d";
            tab11.style.color = "#b2b2b2";
            tab22.style.color = "#ffffff";
            tab33.style.color = "#b2b2b2";
            tab44.style.color = "#b2b2b2";
            tab55.style.color = "#b2b2b2";
        }

        if (currentTab == 3) {
            tabSelected = 3;
            tab3.checked = true;
            view.id = "NoView";
            view.style.display = "none";
            view2.id = "NoView";
            view2.style.display = "none";
            view3.id = "currentView";
            view3.style.display = "block";
            view4.id = "NoView";
            view4.style.display = "none";
            view5.id = "NoView";
            view5.style.display = "none";
            tab11.classList.remove("active")
            tab22.classList.remove("active")
            tab33.classList.add("active")
            tab44.classList.remove("active")
            tab55.classList.remove("active")
            tab11.style.backgroundColor = "#5d5d5d";
            tab22.style.backgroundColor = "#5d5d5d";
            tab33.style.backgroundColor = "#383838";
            tab44.style.backgroundColor = "#5d5d5d";
            tab55.style.backgroundColor = "#5d5d5d";
            tab11.style.color = "#b2b2b2";
            tab22.style.color = "#b2b2b2";
            tab33.style.color = "#ffffff";
            tab44.style.color = "#b2b2b2";
            tab55.style.color = "#b2b2b2";
        }

        if (currentTab == 4) {
            tabSelected = 4;
            tab4.checked = true;
            view.id = "NoView";
            view.style.display = "none";
            view2.id = "NoView";
            view2.style.display = "none";
            view3.id = "NoView";
            view3.style.display = "none";
            view4.id = "currentView";
            view4.style.display = "block";
            view5.id = "NoView";
            view5.style.display = "none";
            tab11.classList.remove("active")
            tab22.classList.remove("active")
            tab33.classList.remove("active")
            tab44.classList.add("active")
            tab55.classList.remove("active")
            tab11.style.backgroundColor = "#5d5d5d";
            tab22.style.backgroundColor = "#5d5d5d";
            tab33.style.backgroundColor = "#5d5d5d";
            tab44.style.backgroundColor = "#383838";
            tab55.style.backgroundColor = "#5d5d5d";
            tab11.style.color = "#b2b2b2";
            tab22.style.color = "#b2b2b2";
            tab33.style.color = "#b2b2b2";
            tab44.style.color = "#ffffff";
            tab55.style.color = "#b2b2b2";
        }
        
        if (currentTab == 5) {
            tabSelected = 5;
            tab5.checked = true;
            view.id = "NoView";
            view.style.display = "none";
            view2.id = "NoView";
            view2.style.display = "none";
            view3.id = "noView";
            view3.style.display = "none";
            view4.id = "NoView";
            view4.style.display = "none";
            view5.id = "currentView";
            view5.style.display = "block";
            tab11.classList.remove("active")
            tab22.classList.remove("active")
            tab33.classList.remove("active")
            tab44.classList.remove("active")
            tab55.classList.add("active")
            tab11.style.backgroundColor = "#5d5d5d";
            tab22.style.backgroundColor = "#5d5d5d";
            tab33.style.backgroundColor = "#5d5d5d";
            tab44.style.backgroundColor = "#5d5d5d";
            tab55.style.backgroundColor = "#383838";
            tab11.style.color = "#b2b2b2";
            tab22.style.color = "#b2b2b2";
            tab33.style.color = "#b2b2b2";
            tab44.style.color = "#b2b2b2";
            tab55.style.color = "#ffffff";
        }
    } else {
        if (document.getElementById("tab1").classList.contains("hidden") && document.getElementById("tab11").classList.contains("hidden")) {
            document.getElementById("tab1").classList.remove("hidden");
            document.getElementById("tab11").classList.remove("hidden");
            document.getElementById("tab1Option").removeAttribute("hidden");
        } else {
            if (document.getElementById("tab2").classList.contains("hidden") && document.getElementById("tab22").classList.contains("hidden")) {
                document.getElementById("tab2").classList.remove("hidden");
                document.getElementById("tab22").classList.remove("hidden");
                document.getElementById("tab2Option").removeAttribute("hidden");
            } else {
                if (document.getElementById("tab3").classList.contains("hidden") && document.getElementById("tab33").classList.contains("hidden")) {
                    document.getElementById("tab3").classList.remove("hidden");
                    document.getElementById("tab33").classList.remove("hidden");
                    document.getElementById("tab3Option").removeAttribute("hidden");
                } else {
                    if (document.getElementById("tab4").classList.contains("hidden") && document.getElementById("tab44").classList.contains("hidden")) {
                        document.getElementById("tab4").classList.remove("hidden");
                        document.getElementById("tab44").classList.remove("hidden");
                        document.getElementById("tab4Option").removeAttribute("hidden");
                    } else {
                        if (document.getElementById("tab5").classList.contains("hidden") && document.getElementById("tab55").classList.contains("hidden")) {
                            document.getElementById("tab5").classList.remove("hidden");
                            document.getElementById("tab55").classList.remove("hidden");
                            document.getElementById("tab5Option").removeAttribute("hidden");
                        }
                    }
                }
            }
        }
    }
    if (tab1.classList.contains("hidden")) {
        tab1Shown = false;
    } else {
        tab1Shown = true;
    }

    if (tab2.classList.contains("hidden")) {
        tab2Shown = false;
    } else {
        tab2Shown = true;
    }

    if (tab3.classList.contains("hidden")) {
        tab3Shown = false;
    } else {
        tab3Shown = true;
    }

    if (tab4.classList.contains("hidden")) {
        tab4Shown = false;
    } else {
        tab4Shown = true;
    }

    if (tab5.classList.contains("hidden")) {
        tab5Shown = false;
    } else {
        tab5Shown = true;
    }
});

tab1.addEventListener('change', function() {
    tab11.style.backgroundColor = "#383838";
    tab22.style.backgroundColor = "#5d5d5d";
    tab33.style.backgroundColor = "#5d5d5d";
    tab44.style.backgroundColor = "#5d5d5d";
    tab55.style.backgroundColor = "#5d5d5d";
    tab11.classList.add("active")
    tab22.classList.remove("active")
    tab33.classList.remove("active")
    tab44.classList.remove("active")
    tab55.classList.remove("active")
    tabSelected = 1;
    view.id = "currentView";
    view.style.display = "block";
    view2.id = "NoView";
    view2.style.display = "none";
    view3.id = "NoView";
    view3.style.display = "none";
    view4.id = "NoView";
    view4.style.display = "none";
    view5.id = "NoView";
    view5.style.display = "none";
    tab11.style.color = "#ffffff";
    tab22.style.color = "#b2b2b2";
    tab33.style.color = "#b2b2b2";
    tab44.style.color = "#b2b2b2";
    tab55.style.color = "#b2b2b2";
})

tab2.addEventListener('change', function() {
    tab11.style.backgroundColor = "#5d5d5d";
    tab22.style.backgroundColor = "#383838";
    tab33.style.backgroundColor = "#5d5d5d";
    tab44.style.backgroundColor = "#5d5d5d";
    tab55.style.backgroundColor = "#5d5d5d";
    tab11.classList.remove("active")
    tab22.classList.add("active")
    tab33.classList.remove("active")
    tab44.classList.remove("active")
    tab55.classList.remove("active")
    tabSelected = 2;
    view.id = "NoView";
    view.style.display = "none";
    view2.id = "currentView";
    view2.style.display = "block";
    view3.id = "NoView";
    view3.style.display = "none";
    view4.id = "NoView";
    view4.style.display = "none";
    view5.id = "NoView";
    view5.style.display = "none";
    tab11.style.color = "#b2b2b2";
    tab22.style.color = "#ffffff";
    tab33.style.color = "#b2b2b2";
    tab44.style.color = "#b2b2b2";
    tab55.style.color = "#b2b2b2";
})

tab3.addEventListener('change', function() {
    tab11.style.backgroundColor = "#5d5d5d";
    tab22.style.backgroundColor = "#5d5d5d";
    tab33.style.backgroundColor = "#383838";
    tab44.style.backgroundColor = "#5d5d5d";
    tab55.style.backgroundColor = "#5d5d5d";
    tab11.classList.remove("active")
    tab22.classList.remove("active")
    tab33.classList.add("active")
    tab44.classList.remove("active")
    tab55.classList.remove("active")
    tabSelected = 3;
    tab3.checked = true;
    view.id = "NoView";
    view.style.display = "none";
    view2.id = "NoView";
    view2.style.display = "none";
    view3.id = "currentView";
    view3.style.display = "block";
    view4.id = "NoView";
    view4.style.display = "none";
    view5.id = "NoView";
    view5.style.display = "none";
    tab11.style.color = "#b2b2b2";
    tab22.style.color = "#b2b2b2";
    tab33.style.color = "#ffffff";
    tab44.style.color = "#b2b2b2";
    tab55.style.color = "#b2b2b2";
})

tab4.addEventListener('change', function() {
    tab11.style.backgroundColor = "#5d5d5d";
    tab22.style.backgroundColor = "#5d5d5d";
    tab33.style.backgroundColor = "#5d5d5d";
    tab44.style.backgroundColor = "#383838";
    tab55.style.backgroundColor = "#5d5d5d";
    tab11.classList.remove("active")
    tab22.classList.remove("active")
    tab33.classList.remove("active")
    tab44.classList.add("active")
    tab55.classList.remove("active")
    tabSelected = 4;
    tab4.checked = true;
    view.id = "NoView";
    view.style.display = "none";
    view2.id = "NoView";
    view2.style.display = "none";
    view3.id = "NoView";
    view3.style.display = "none";
    view4.id = "currentView";
    view4.style.display = "block";
    view5.id = "NoView";
    view5.style.display = "none";
    tab11.style.color = "#b2b2b2";
    tab22.style.color = "#b2b2b2";
    tab33.style.color = "#b2b2b2";
    tab44.style.color = "#ffffff";
    tab55.style.color = "#b2b2b2";
})

tab5.addEventListener('change', function() {
    tab11.style.backgroundColor = "#5d5d5d";
    tab22.style.backgroundColor = "#5d5d5d";
    tab33.style.backgroundColor = "#5d5d5d";
    tab44.style.backgroundColor = "#5d5d5d";
    tab55.style.backgroundColor = "#383838";
    tab11.classList.remove("active")
    tab22.classList.remove("active")
    tab33.classList.remove("active")
    tab44.classList.remove("active")
    tab55.classList.add("active")
    tabSelected = 5;
    tab5.checked = true;
    view.id = "NoView";
    view.style.display = "none";
    view2.id = "NoView";
    view2.style.display = "none";
    view3.id = "noView";
    view3.style.display = "none";
    view4.id = "NoView";
    view4.style.display = "none";
    view5.id = "currentView";
    view5.style.display = "block";
    tab11.style.color = "#b2b2b2";
    tab22.style.color = "#b2b2b2";
    tab33.style.color = "#b2b2b2";
    tab44.style.color = "#b2b2b2";
    tab55.style.color = "#ffffff";
})

selection.addEventListener('change', () => {
    if (selection.selectedIndex == 1) {
        document.getElementById("tab1Option").setAttribute("hidden", "true");
        document.getElementById("tab1").classList.add("hidden");
        document.getElementById("tab11").classList.add("hidden");
        view.id = "NoView";
        view.style.display = "none";
        if (saveTabData == false) {
            view.src = "https://www.google.com";
        }
    }

    if (selection.selectedIndex == 2) {
        document.getElementById("tab2Option").setAttribute("hidden", "true");
        document.getElementById("tab2").classList.add("hidden");
        document.getElementById("tab22").classList.add("hidden");
        view2.id = "NoView";
        view2.style.display = "none";
        if (saveTabData == false) {
            view2.src = "https://www.google.com";
        }
    }

    if (selection.selectedIndex == 3) {
        document.getElementById("tab3Option").setAttribute("hidden", "true");
        document.getElementById("tab3").classList.add("hidden");
        document.getElementById("tab33").classList.add("hidden");
        view3.id = "NoView";
        view3.style.display = "none";
        if (saveTabData == false) {
            view3.src = "https://www.google.com";
        }
    }
    
    if (selection.selectedIndex == 4) {
        document.getElementById("tab4Option").setAttribute("hidden", "true");
        document.getElementById("tab4").classList.add("hidden");
        document.getElementById("tab44").classList.add("hidden");
        view4.id = "NoView";
        view4.style.display = "none";
        if (saveTabData == false) {
            view4.src = "https://www.google.com";
        }
    }
    
    if (selection.selectedIndex == 5) {
        document.getElementById("tab5Option").setAttribute("hidden", "true");
        document.getElementById("tab5").classList.add("hidden");
        document.getElementById("tab55").classList.add("hidden");
        view5.id = "NoView";
        view5.style.display = "none";
        if (saveTabData == false) {
            view5.src = "https://www.google.com";
        }
    }

    if (tab1.classList.contains("hidden")) {
        tab1Shown = false;
    } else {
        tab1Shown = true;
    }

    if (tab2.classList.contains("hidden")) {
        tab2Shown = false;
    } else {
        tab2Shown = true;
    }

    if (tab3.classList.contains("hidden")) {
        tab3Shown = false;
    } else {
        tab3Shown = true;
    }

    if (tab4.classList.contains("hidden")) {
        tab4Shown = false;
    } else {
        tab4Shown = true;
    }

    if (tab5.classList.contains("hidden")) {
        tab5Shown = false;
    } else {
        tab5Shown = true;
    }
});

xtab1.addEventListener("click", function() {
    document.getElementById("tab1Option").setAttribute("hidden", "true");
    document.getElementById("tab1").classList.add("hidden");
    document.getElementById("tab11").classList.add("hidden");
    view.id = "NoView";
    view.style.display = "none";
    if (saveTabData == false) {
        view.src = "https://www.google.com";
    }
    tab11.classList.remove("active")
});

xtab2.addEventListener("click", function() {
    document.getElementById("tab2Option").setAttribute("hidden", "true");
    document.getElementById("tab2").classList.add("hidden");
    document.getElementById("tab22").classList.add("hidden");
    view2.id = "NoView";
    view2.style.display = "none";
    if (saveTabData == false) {
        view2.src = "https://www.google.com";
    }
    tab22.classList.remove("active")
});

xtab3.addEventListener("click", function() {
    document.getElementById("tab3Option").setAttribute("hidden", "true");
    document.getElementById("tab3").classList.add("hidden");
    document.getElementById("tab33").classList.add("hidden");
    view3.id = "NoView";
    view3.style.display = "none";
    if (saveTabData == false) {
        view3.src = "https://www.google.com";
    }
    tab33.classList.remove("active")
});

xtab4.addEventListener("click", function() {
    document.getElementById("tab4Option").setAttribute("hidden", "true");
    document.getElementById("tab4").classList.add("hidden");
    document.getElementById("tab44").classList.add("hidden");
    view4.id = "NoView";
    view4.style.display = "none";
    if (saveTabData == false) {
        view4.src = "https://www.google.com";
    }
    tab44.classList.remove("active")
});

xtab5.addEventListener("click", function() {
    document.getElementById("tab5Option").setAttribute("hidden", "true");
    document.getElementById("tab5").classList.add("hidden");
    document.getElementById("tab55").classList.add("hidden");
    view5.id = "NoView";
    view5.style.display = "none";
    if (saveTabData == false) {
        view5.src = "https://www.google.com";
    }
    tab55.classList.remove("active")
});

var bookmark1 = "";
var bookmark2 = "";
var bookmark3 = "";
var bookmark4 = "";
var bookmark5 = "";

/*bookmarkSelection.addEventListener('change', () => {
    if (bookmarkSelection.selectedIndex == 1) {
        bookmark1 = document.getElementById("bookmarkInput").value;
    }

    if (bookmarkSelection.selectedIndex == 2) {
        bookmark2 = document.getElementById("bookmarkInput").value;
    }

    if (bookmarkSelection.selectedIndex == 3) {
        bookmark3 = document.getElementById("bookmarkInput").value;
    }
    
    if (bookmarkSelection.selectedIndex == 4) {
        bookmark4 = document.getElementById("bookmarkInput").value;
    }
    
    if (bookmarkSelection.selectedIndex == 5) {
        bookmark5 = document.getElementById("bookmarkInput").value;
    }

    document.getElementById("bookmarkInput").value = "";
});*/

document.getElementById("bookmark1").addEventListener('click', function() {
    webview.src = bookmark1;
});

document.getElementById("bookmark2").addEventListener('click', function() {
    webview.src = bookmark2;
});

document.getElementById("bookmark3").addEventListener('click', function() {
    webview.src = bookmark3;
});

document.getElementById("bookmark4").addEventListener('click', function() {
    webview.src = bookmark4;
});

document.getElementById("bookmark5").addEventListener('click', function() {
    webview.src = bookmark5;
});